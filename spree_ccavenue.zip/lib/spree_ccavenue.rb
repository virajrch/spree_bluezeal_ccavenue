require 'spree_core'
require 'spree_ccavenue/engine'
