if Object.const_defined?("Devise")
  Devise.secret_key = "42f5083e3144d75e67f4d886b496bb6ca4f27deee8cf875951d9ac946a665c27537bfab02655c385798592c8a721183838fa"
end