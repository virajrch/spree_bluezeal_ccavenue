module Spree::Ccavenue
  def self.table_name_prefix
    'spree_ccavenue_'
  end
end
